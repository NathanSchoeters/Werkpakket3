-- MySQL dump 10.13  Distrib 8.0.33, for Linux (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	8.0.33-0ubuntu0.20.04.2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `addresses` (
  `id` int NOT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `countryCode` varchar(255) NOT NULL,
  `administrativeArea` varchar(255) DEFAULT NULL,
  `locality` varchar(255) DEFAULT NULL,
  `dependentLocality` varchar(255) DEFAULT NULL,
  `postalCode` varchar(255) DEFAULT NULL,
  `sortingCode` varchar(255) DEFAULT NULL,
  `addressLine1` varchar(255) DEFAULT NULL,
  `addressLine2` varchar(255) DEFAULT NULL,
  `addressLine3` varchar(255) DEFAULT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `organizationTaxId` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `latitude` varchar(255) DEFAULT NULL,
  `longitude` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_voquyrsqjextfbisoiieejojqngozdrxuntq` (`primaryOwnerId`),
  CONSTRAINT `fk_leegdybphlvpsajgexrjuiwqnqvkzhtioami` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_voquyrsqjextfbisoiieejojqngozdrxuntq` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `addresses`
--

LOCK TABLES `addresses` WRITE;
/*!40000 ALTER TABLE `addresses` DISABLE KEYS */;
/*!40000 ALTER TABLE `addresses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcements`
--

DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `pluginId` int DEFAULT NULL,
  `heading` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `unread` tinyint(1) NOT NULL DEFAULT '1',
  `dateRead` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_alhnrtmldolilhqqaczucilttndhzbykicpp` (`userId`,`unread`,`dateRead`,`dateCreated`),
  KEY `idx_czjqkttclmommfzlqwgaszhokswttidwixqz` (`dateRead`),
  KEY `fk_onechjwaeslmrmtkhzwpgxgrveplqvtjspln` (`pluginId`),
  CONSTRAINT `fk_jlpuwjpdkdsxjavewxfvdihisdeiqabpwwhw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_onechjwaeslmrmtkhzwpgxgrveplqvtjspln` FOREIGN KEY (`pluginId`) REFERENCES `plugins` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcements`
--

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexdata`
--

DROP TABLE IF EXISTS `assetindexdata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexdata` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sessionId` int NOT NULL,
  `volumeId` int NOT NULL,
  `uri` text,
  `size` bigint unsigned DEFAULT NULL,
  `timestamp` datetime DEFAULT NULL,
  `isDir` tinyint(1) DEFAULT '0',
  `recordId` int DEFAULT NULL,
  `isSkipped` tinyint(1) DEFAULT '0',
  `inProgress` tinyint(1) DEFAULT '0',
  `completed` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_smwxfhqwcmmrtxmihgztxsckisjvcckqyrea` (`sessionId`,`volumeId`),
  KEY `idx_pvxcxaqogkkjxvyaiemxlkycydudqdlcizhc` (`volumeId`),
  CONSTRAINT `fk_bipmtqiibmkxtqtowwmrdyzbseccowqfbniv` FOREIGN KEY (`sessionId`) REFERENCES `assetindexingsessions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fjrsvsbgqyhirsdvonmqvcpngslvdsavwgfp` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexdata`
--

LOCK TABLES `assetindexdata` WRITE;
/*!40000 ALTER TABLE `assetindexdata` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexdata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assetindexingsessions`
--

DROP TABLE IF EXISTS `assetindexingsessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assetindexingsessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `indexedVolumes` text,
  `totalEntries` int DEFAULT NULL,
  `processedEntries` int NOT NULL DEFAULT '0',
  `cacheRemoteImages` tinyint(1) DEFAULT NULL,
  `listEmptyFolders` tinyint(1) DEFAULT '0',
  `isCli` tinyint(1) DEFAULT '0',
  `actionRequired` tinyint(1) DEFAULT '0',
  `processIfRootEmpty` tinyint(1) DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assetindexingsessions`
--

LOCK TABLES `assetindexingsessions` WRITE;
/*!40000 ALTER TABLE `assetindexingsessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `assetindexingsessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets`
--

DROP TABLE IF EXISTS `assets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets` (
  `id` int NOT NULL,
  `volumeId` int DEFAULT NULL,
  `folderId` int NOT NULL,
  `uploaderId` int DEFAULT NULL,
  `filename` varchar(255) NOT NULL,
  `kind` varchar(50) NOT NULL DEFAULT 'unknown',
  `alt` text,
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `size` bigint unsigned DEFAULT NULL,
  `focalPoint` varchar(13) DEFAULT NULL,
  `deletedWithVolume` tinyint(1) DEFAULT NULL,
  `keptFile` tinyint(1) DEFAULT NULL,
  `dateModified` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_xmyxpfxcvhvbetcbelflpammsnolmlyknpqb` (`filename`,`folderId`),
  KEY `idx_krjkgyoasprvufitfjilmdunhbtwzobwdise` (`folderId`),
  KEY `idx_zvyijopmiixpfqewuxeehrvqgjwhzeuebxbe` (`volumeId`),
  KEY `fk_ieujpvktvpqnumhfwdycpovzwjxbqttcorvp` (`uploaderId`),
  CONSTRAINT `fk_hebnbqxjhcraxwplvpxismpgwffsbnxlywie` FOREIGN KEY (`folderId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ieujpvktvpqnumhfwdycpovzwjxbqttcorvp` FOREIGN KEY (`uploaderId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_slsglvgrxkbfkkbkinbwsuabxfzocmeyluqd` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_zmytuqcgduzryftphlokbuktjsapwuxkwqbo` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets`
--

LOCK TABLES `assets` WRITE;
/*!40000 ALTER TABLE `assets` DISABLE KEYS */;
INSERT INTO `assets` VALUES (4,1,1,1,'Illustrashop.png','image',NULL,603,134,8043,NULL,0,0,'2024-05-02 12:51:42','2024-05-02 12:51:42','2024-05-02 12:51:42'),(7,1,1,1,'Illustrashop.png','image',NULL,603,134,8043,NULL,NULL,NULL,'2024-05-02 12:57:28','2024-05-02 12:57:28','2024-05-02 12:57:28'),(12,1,1,1,'Illustration1.png','image',NULL,608,1143,84863,NULL,NULL,NULL,'2024-05-02 13:11:14','2024-05-02 13:11:14','2024-05-02 13:11:14');
/*!40000 ALTER TABLE `assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `assets_sites`
--

DROP TABLE IF EXISTS `assets_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `assets_sites` (
  `assetId` int NOT NULL,
  `siteId` int NOT NULL,
  `alt` text,
  PRIMARY KEY (`assetId`,`siteId`),
  KEY `fk_dlotvzfxjjsivksmxmvzraeqjreeuerzedcw` (`siteId`),
  CONSTRAINT `fk_dlotvzfxjjsivksmxmvzraeqjreeuerzedcw` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_gfjjdhbynjteqpngzmnazlvjhtyfcpmfitys` FOREIGN KEY (`assetId`) REFERENCES `assets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assets_sites`
--

LOCK TABLES `assets_sites` WRITE;
/*!40000 ALTER TABLE `assets_sites` DISABLE KEYS */;
INSERT INTO `assets_sites` VALUES (4,1,NULL),(7,1,NULL),(12,1,NULL);
/*!40000 ALTER TABLE `assets_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `authenticator`
--

DROP TABLE IF EXISTS `authenticator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `authenticator` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `auth2faSecret` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_fwyszrfcrjlrtmfxjvaljvyezwmbnjrsutjq` (`userId`),
  CONSTRAINT `fk_fwyszrfcrjlrtmfxjvaljvyezwmbnjrsutjq` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `authenticator`
--

LOCK TABLES `authenticator` WRITE;
/*!40000 ALTER TABLE `authenticator` DISABLE KEYS */;
/*!40000 ALTER TABLE `authenticator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `parentId` int DEFAULT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_qqrschsucngqdxwlwmerkpysbddfnvmzazmg` (`groupId`),
  KEY `fk_checcmazkiyhtjkzbhjcyflccfkimvtdfgca` (`parentId`),
  CONSTRAINT `fk_checcmazkiyhtjkzbhjcyflccfkimvtdfgca` FOREIGN KEY (`parentId`) REFERENCES `categories` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_qulbvyhmzdxegwflafsmvyaoqogpvuymsina` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_wbntsqmkpjziasnyjqpfcsdojrussrejdxgj` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups`
--

DROP TABLE IF EXISTS `categorygroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_utdosnxspzgawvvglnlphwbncrehvaectbyz` (`name`),
  KEY `idx_eclrctjvfipmwqhbvwtptsonryykaqstilcv` (`handle`),
  KEY `idx_wijerlptjvignhacqfoiualbgrguyeybezsb` (`structureId`),
  KEY `idx_rkuofsdgzadncshrzvdxkkqmuyvlqwabkspo` (`fieldLayoutId`),
  KEY `idx_znplcnymoggsilgpllhwsyeedxsvtybpmuyk` (`dateDeleted`),
  CONSTRAINT `fk_cononizsrsqjlyhswwtxuahqhwcznydgfvud` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ecyokmmtntlkrxzkzwpaegkdnlsnnnxapigq` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups`
--

LOCK TABLES `categorygroups` WRITE;
/*!40000 ALTER TABLE `categorygroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorygroups_sites`
--

DROP TABLE IF EXISTS `categorygroups_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorygroups_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_museyuxtczgztfxyobmmtrtnopunfsvptcjd` (`groupId`,`siteId`),
  KEY `idx_oplzytqbhdhfhvjbynazlimxdwgbimmfjqhq` (`siteId`),
  CONSTRAINT `fk_sdemfdftkbhbndogizedfdzloyuikwayjcki` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tlvlymrkcoxciglfpaojivcgdtrointujjpt` FOREIGN KEY (`groupId`) REFERENCES `categorygroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorygroups_sites`
--

LOCK TABLES `categorygroups_sites` WRITE;
/*!40000 ALTER TABLE `categorygroups_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorygroups_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedattributes`
--

DROP TABLE IF EXISTS `changedattributes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedattributes` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `attribute` varchar(255) NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`attribute`),
  KEY `idx_ioafztfcdbbkvvlmgkbfjjnfotdkhwwafhuv` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_rpydylmkrlinikwbvrazhjytyljhkziujjab` (`siteId`),
  KEY `fk_dwzegpnhdvwklowdygtpkzowpisireybepoz` (`userId`),
  CONSTRAINT `fk_dwzegpnhdvwklowdygtpkzowpisireybepoz` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_rpydylmkrlinikwbvrazhjytyljhkziujjab` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_uhelnwxnqkiyasepjmakbvacirzfydjurggl` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedattributes`
--

LOCK TABLES `changedattributes` WRITE;
/*!40000 ALTER TABLE `changedattributes` DISABLE KEYS */;
/*!40000 ALTER TABLE `changedattributes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `changedfields`
--

DROP TABLE IF EXISTS `changedfields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `changedfields` (
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `fieldId` int NOT NULL,
  `layoutElementUid` char(36) NOT NULL DEFAULT '0',
  `dateUpdated` datetime NOT NULL,
  `propagated` tinyint(1) NOT NULL,
  `userId` int DEFAULT NULL,
  PRIMARY KEY (`elementId`,`siteId`,`fieldId`,`layoutElementUid`),
  KEY `idx_ntbqgwgcphjuvrwvuflpiiqlgyikzikhcmid` (`elementId`,`siteId`,`dateUpdated`),
  KEY `fk_lvvslxldsnwpsuvrcsmqrpojkalxxxgabxmx` (`siteId`),
  KEY `fk_guibrnvqeajtlqjiynsvewfmtburmuwjaogc` (`fieldId`),
  KEY `fk_mcomgoygaftfyuijmttafbyleqchqkkdphyd` (`userId`),
  CONSTRAINT `fk_ddchzdensptrwnzkdcjkjowcqmzjrhdkudqy` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_guibrnvqeajtlqjiynsvewfmtburmuwjaogc` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_lvvslxldsnwpsuvrcsmqrpojkalxxxgabxmx` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_mcomgoygaftfyuijmttafbyleqchqkkdphyd` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `changedfields`
--

LOCK TABLES `changedfields` WRITE;
/*!40000 ALTER TABLE `changedfields` DISABLE KEYS */;
INSERT INTO `changedfields` VALUES (2,1,1,'3c1e13ab-a927-4726-a034-0fa67104053a','2024-05-02 12:58:06',0,1),(10,1,1,'5e2a9b23-1058-45d7-90bd-c052aca2b00b','2024-05-02 13:11:17',0,1);
/*!40000 ALTER TABLE `changedfields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `craftidtokens`
--

DROP TABLE IF EXISTS `craftidtokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `craftidtokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `accessToken` text NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_nhclqfnytyceeselwzuhrzyxqtollmlqicrt` (`userId`),
  CONSTRAINT `fk_nhclqfnytyceeselwzuhrzyxqtollmlqicrt` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `craftidtokens`
--

LOCK TABLES `craftidtokens` WRITE;
/*!40000 ALTER TABLE `craftidtokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `craftidtokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deprecationerrors`
--

DROP TABLE IF EXISTS `deprecationerrors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deprecationerrors` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `lastOccurrence` datetime NOT NULL,
  `file` varchar(255) NOT NULL,
  `line` smallint unsigned DEFAULT NULL,
  `message` text,
  `traces` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_dncpwknloblrmlialzsjdrvbjizmcootpshh` (`key`,`fingerprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deprecationerrors`
--

LOCK TABLES `deprecationerrors` WRITE;
/*!40000 ALTER TABLE `deprecationerrors` DISABLE KEYS */;
/*!40000 ALTER TABLE `deprecationerrors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drafts`
--

DROP TABLE IF EXISTS `drafts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drafts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `creatorId` int DEFAULT NULL,
  `provisional` tinyint(1) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `notes` text,
  `trackChanges` tinyint(1) NOT NULL DEFAULT '0',
  `dateLastMerged` datetime DEFAULT NULL,
  `saved` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_lficieuhmdnolzcjcgnwikhpwatcvgvcodtp` (`creatorId`,`provisional`),
  KEY `idx_ptbxxmbwixezdyoxmhpkpvpzedasuacyihff` (`saved`),
  KEY `fk_doxrdubpadfazecdherbvdtkhjbobzegpdwy` (`canonicalId`),
  CONSTRAINT `fk_doxrdubpadfazecdherbvdtkhjbobzegpdwy` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kjskdtcgnantqisdroglyzcnipcufwnjqrqp` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drafts`
--

LOCK TABLES `drafts` WRITE;
/*!40000 ALTER TABLE `drafts` DISABLE KEYS */;
/*!40000 ALTER TABLE `drafts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elementactivity`
--

DROP TABLE IF EXISTS `elementactivity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elementactivity` (
  `elementId` int NOT NULL,
  `userId` int NOT NULL,
  `siteId` int NOT NULL,
  `draftId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`elementId`,`userId`,`type`),
  KEY `idx_zacdnjjnlhuepjrkylupflftznolugtkamsr` (`elementId`,`timestamp`,`userId`),
  KEY `fk_ujvneuytcgvagqglqftymahhuttjjkfdyqay` (`userId`),
  KEY `fk_brulloqwamficqwoigswrdewgujlcsfsvnxd` (`siteId`),
  KEY `fk_mkedmaxgxzfsrjvtxpinubcplfypvsdpbwpo` (`draftId`),
  CONSTRAINT `fk_brulloqwamficqwoigswrdewgujlcsfsvnxd` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lzqtcwecgwpnavtqspmdgpucszjwplwkwvkc` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_mkedmaxgxzfsrjvtxpinubcplfypvsdpbwpo` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_ujvneuytcgvagqglqftymahhuttjjkfdyqay` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elementactivity`
--

LOCK TABLES `elementactivity` WRITE;
/*!40000 ALTER TABLE `elementactivity` DISABLE KEYS */;
INSERT INTO `elementactivity` VALUES (2,1,1,NULL,'edit','2024-05-02 12:58:04'),(2,1,1,NULL,'save','2024-05-02 12:58:06'),(4,1,1,NULL,'save','2024-05-02 12:57:07'),(10,1,1,NULL,'edit','2024-05-02 13:11:14'),(10,1,1,NULL,'save','2024-05-02 13:11:17');
/*!40000 ALTER TABLE `elementactivity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements`
--

DROP TABLE IF EXISTS `elements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int DEFAULT NULL,
  `draftId` int DEFAULT NULL,
  `revisionId` int DEFAULT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `archived` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateLastMerged` datetime DEFAULT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `deletedWithOwner` tinyint(1) DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_wbobcmtiggjvscikgccpjclmixycevcnacwt` (`dateDeleted`),
  KEY `idx_phynoukpnqhbspzrlwboabowxpxgaurcrdtm` (`fieldLayoutId`),
  KEY `idx_mhfzmlcoyknlqrcbidgipwgpoveidpedayto` (`type`),
  KEY `idx_wbgeurwbvyckypkzjwhwabacellllyuzzpjj` (`enabled`),
  KEY `idx_soqqkgkbarxisqnxrwntuouxlkbabevqhept` (`canonicalId`),
  KEY `idx_mrxwlhpstsjwaxxarfcfdrnfsyfxtnbjgjfk` (`archived`,`dateCreated`),
  KEY `idx_rlfcbyrdrofucpodkeqdwwbsgrhqzrvnnbue` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`),
  KEY `idx_shajpajtyqekanmhfbxnwviwvgokbozxwdyc` (`archived`,`dateDeleted`,`draftId`,`revisionId`,`canonicalId`,`enabled`),
  KEY `fk_ykrhtkklzeaytafbkeaeaiepfivmxrrgoryz` (`draftId`),
  KEY `fk_lquiwvmtykcqctfrjirkrdyczltdbtixvrok` (`revisionId`),
  CONSTRAINT `fk_cfkfkkqhxmbkawlmygnuoxhwwdkvxmkokcgw` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lquiwvmtykcqctfrjirkrdyczltdbtixvrok` FOREIGN KEY (`revisionId`) REFERENCES `revisions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tsoqkzreljuqkqqjotjkjiuobftbdkppgbsn` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ykrhtkklzeaytafbkeaeaiepfivmxrrgoryz` FOREIGN KEY (`draftId`) REFERENCES `drafts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements`
--

LOCK TABLES `elements` WRITE;
/*!40000 ALTER TABLE `elements` DISABLE KEYS */;
INSERT INTO `elements` VALUES (1,NULL,NULL,NULL,NULL,'craft\\elements\\User',1,0,'2024-04-30 12:49:40','2024-04-30 12:49:40',NULL,NULL,NULL,'fa7b3397-150a-48f5-bd9e-18483a3c7ad3'),(2,NULL,NULL,NULL,1,'craft\\elements\\Entry',1,0,'2024-05-02 12:35:20','2024-05-02 12:58:06',NULL,NULL,NULL,'5a726b82-d76c-4bc3-a699-7c5425dc5db0'),(3,2,NULL,1,1,'craft\\elements\\Entry',1,0,'2024-05-02 12:35:20','2024-05-02 12:35:20',NULL,NULL,NULL,'fd75a6b1-6108-4a73-bacf-5c846d33967a'),(4,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-05-02 12:51:42','2024-05-02 12:57:24',NULL,'2024-05-02 12:57:24',NULL,'04d43fe5-3312-4904-ad32-fdb9ba2e4308'),(6,2,NULL,2,1,'craft\\elements\\Entry',1,0,'2024-05-02 12:51:45','2024-05-02 12:51:45',NULL,NULL,NULL,'c9b34b94-b570-4454-9235-760f3f611e99'),(7,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-05-02 12:57:28','2024-05-02 12:57:28',NULL,NULL,NULL,'84ea8e95-8794-4449-87f8-50ed8f005eff'),(9,2,NULL,3,1,'craft\\elements\\Entry',1,0,'2024-05-02 12:58:06','2024-05-02 12:58:06',NULL,NULL,NULL,'bee85780-1bc8-42b3-ae5a-e2b12e8b799b'),(10,NULL,NULL,NULL,3,'craft\\elements\\Entry',1,0,'2024-05-02 13:11:08','2024-05-02 13:11:17',NULL,NULL,NULL,'745fba18-1d82-4146-863d-8a7cae60fc0c'),(11,10,NULL,4,3,'craft\\elements\\Entry',1,0,'2024-05-02 13:11:08','2024-05-02 13:11:08',NULL,NULL,NULL,'e27bb93f-2067-4268-a88e-cb516aa04e3f'),(12,NULL,NULL,NULL,2,'craft\\elements\\Asset',1,0,'2024-05-02 13:11:14','2024-05-02 13:11:14',NULL,NULL,NULL,'ba395339-20aa-4174-bd04-ccbcfbc3b7d4'),(14,10,NULL,5,3,'craft\\elements\\Entry',1,0,'2024-05-02 13:11:17','2024-05-02 13:11:17',NULL,NULL,NULL,'ba46d838-bff4-43ea-a661-af6dc0f8ee73');
/*!40000 ALTER TABLE `elements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_bulkops`
--

DROP TABLE IF EXISTS `elements_bulkops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_bulkops` (
  `elementId` int NOT NULL,
  `key` char(10) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`elementId`,`key`),
  KEY `idx_fwfekwtxoygcrqernkoxvuurotthqumrtpsh` (`timestamp`),
  CONSTRAINT `fk_fzqxfrcstogyyqlhbypflnqgqycxfieyqwbz` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_bulkops`
--

LOCK TABLES `elements_bulkops` WRITE;
/*!40000 ALTER TABLE `elements_bulkops` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_bulkops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_owners`
--

DROP TABLE IF EXISTS `elements_owners`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_owners` (
  `elementId` int NOT NULL,
  `ownerId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`elementId`,`ownerId`),
  KEY `fk_tjxshhpvgaquazplqoumfvpmyqmcneisqjge` (`ownerId`),
  CONSTRAINT `fk_dngkoiscfkdstdwrqsbluhvdvctzbipkiisb` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tjxshhpvgaquazplqoumfvpmyqmcneisqjge` FOREIGN KEY (`ownerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_owners`
--

LOCK TABLES `elements_owners` WRITE;
/*!40000 ALTER TABLE `elements_owners` DISABLE KEYS */;
/*!40000 ALTER TABLE `elements_owners` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `elements_sites`
--

DROP TABLE IF EXISTS `elements_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `elements_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `elementId` int NOT NULL,
  `siteId` int NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `content` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ufrmzdohgvlhlovkbkncsctgqopnqwybdvux` (`elementId`,`siteId`),
  KEY `idx_quyfrdpgurcslhjcyisczqmaylhekkeilthe` (`siteId`),
  KEY `idx_oxqcymrfwmejjpybjshdefppsuxywnsaihnv` (`title`,`siteId`),
  KEY `idx_tqinvuppzbgwccccucywozrxkhibbddbmizk` (`slug`,`siteId`),
  KEY `idx_ivnnpbfhugucmxhxzqnujqseaxpphhutodyj` (`enabled`),
  KEY `idx_uvrxorlnrdjbrtpqossdztpbxyqkkqxwjymj` (`uri`,`siteId`),
  CONSTRAINT `fk_ipabrqjrczbfnrkhnxptkqmxgucttveyqinw` FOREIGN KEY (`elementId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_msttykjwhgldpdgtseugjsomoqjdmoalbjem` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `elements_sites`
--

LOCK TABLES `elements_sites` WRITE;
/*!40000 ALTER TABLE `elements_sites` DISABLE KEYS */;
INSERT INTO `elements_sites` VALUES (1,1,1,NULL,NULL,NULL,NULL,1,'2024-04-30 12:49:40','2024-04-30 12:49:40','2e6a9fdc-1ff0-4ac6-ace5-337ea61fce2b'),(2,2,1,'Home','home','__home__',NULL,1,'2024-05-02 12:35:20','2024-05-02 12:35:20','be5f8f9c-faa2-4360-8cfb-2de8008581ce'),(3,3,1,'Home','home','__home__',NULL,1,'2024-05-02 12:35:20','2024-05-02 12:35:20','f1c8388f-9885-4720-8498-81ba7e50234c'),(4,4,1,'Illustrashop',NULL,NULL,NULL,1,'2024-05-02 12:51:42','2024-05-02 12:51:42','ec9c19d8-4030-4a42-9ef9-0aa9dce07c37'),(6,6,1,'Home','home','__home__',NULL,1,'2024-05-02 12:51:45','2024-05-02 12:51:45','0a91dcff-7f08-46e2-82d2-208b5270a7cd'),(7,7,1,'Illustrashop',NULL,NULL,NULL,1,'2024-05-02 12:57:28','2024-05-02 12:57:28','b3a683c0-ff18-410f-82a0-081101e11bae'),(9,9,1,'Home','home','__home__',NULL,1,'2024-05-02 12:58:06','2024-05-02 12:58:06','9265a124-0c07-4aa6-bbf1-4a020b8948ad'),(10,10,1,'About','about','about',NULL,1,'2024-05-02 13:11:08','2024-05-02 13:11:08','4f5d8464-dc32-4c6b-a296-3b9a73abef05'),(11,11,1,'About','about','about',NULL,1,'2024-05-02 13:11:08','2024-05-02 13:11:08','35def4d8-5e0f-436a-af36-1d737d7a5de8'),(12,12,1,'Illustration1',NULL,NULL,NULL,1,'2024-05-02 13:11:14','2024-05-02 13:11:14','4cc7c250-da0a-48f3-a9fc-922bd3d1ee01'),(14,14,1,'About','about','about',NULL,1,'2024-05-02 13:11:17','2024-05-02 13:11:17','a8def93a-cb7a-4139-a3ba-84b2f393d00b');
/*!40000 ALTER TABLE `elements_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries`
--

DROP TABLE IF EXISTS `entries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries` (
  `id` int NOT NULL,
  `sectionId` int DEFAULT NULL,
  `parentId` int DEFAULT NULL,
  `primaryOwnerId` int DEFAULT NULL,
  `fieldId` int DEFAULT NULL,
  `typeId` int NOT NULL,
  `postDate` datetime DEFAULT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `deletedWithEntryType` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_rlchtjgruqwvmrshbjzwroejzoqhjqlgbnji` (`postDate`),
  KEY `idx_zdeyldxfhwfkblmgxgtljyfqzrjcpabxdsww` (`expiryDate`),
  KEY `idx_ybkhqdrjcvpycspgtkjyrdfzhqkrkxenaxtf` (`sectionId`),
  KEY `idx_cefyjhbnpgrqmnjoozsidgydzodxrfqiqtdx` (`typeId`),
  KEY `idx_ynuutxazgdqxjxvjiytxlenggdlxltsetqin` (`primaryOwnerId`),
  KEY `idx_bnozkzyuevoqmesamaiobqzoryxdaqmesbzy` (`fieldId`),
  KEY `fk_vaqawkmeasvznvkaiyefdxjwcuonvuzlstlg` (`parentId`),
  CONSTRAINT `fk_ayqzpwygqppuxgyejevxwjionnlqtxwgwlcp` FOREIGN KEY (`primaryOwnerId`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_azqzpsqgtajaaghgcdhyebctmjzucfkrjsje` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_toipyzogaaiklrfxdmsrsaarppgpvcfwppfo` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tonofevfnaqktcqxbkowargbvbewrvwsxxju` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_vaqawkmeasvznvkaiyefdxjwcuonvuzlstlg` FOREIGN KEY (`parentId`) REFERENCES `entries` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_ywqhhokjcqthsagtzvolddsyajhjwfnzpudh` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries`
--

LOCK TABLES `entries` WRITE;
/*!40000 ALTER TABLE `entries` DISABLE KEYS */;
INSERT INTO `entries` VALUES (2,1,NULL,NULL,NULL,1,'2024-05-02 12:35:00',NULL,NULL,'2024-05-02 12:35:20','2024-05-02 12:35:20'),(3,1,NULL,NULL,NULL,1,'2024-05-02 12:35:00',NULL,NULL,'2024-05-02 12:35:20','2024-05-02 12:35:20'),(6,1,NULL,NULL,NULL,1,'2024-05-02 12:35:00',NULL,NULL,'2024-05-02 12:51:45','2024-05-02 12:51:45'),(9,1,NULL,NULL,NULL,1,'2024-05-02 12:35:00',NULL,NULL,'2024-05-02 12:58:06','2024-05-02 12:58:06'),(10,2,NULL,NULL,NULL,2,'2024-05-02 13:11:00',NULL,NULL,'2024-05-02 13:11:08','2024-05-02 13:11:08'),(11,2,NULL,NULL,NULL,2,'2024-05-02 13:11:00',NULL,NULL,'2024-05-02 13:11:08','2024-05-02 13:11:08'),(14,2,NULL,NULL,NULL,2,'2024-05-02 13:11:00',NULL,NULL,'2024-05-02 13:11:17','2024-05-02 13:11:17');
/*!40000 ALTER TABLE `entries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entries_authors`
--

DROP TABLE IF EXISTS `entries_authors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entries_authors` (
  `entryId` int NOT NULL,
  `authorId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`entryId`,`authorId`),
  KEY `idx_ysknjqozedvtoqfyocjgkixouumpqrcfdrul` (`authorId`),
  KEY `idx_wwxidizduuoysczlfazuokitfktjpyxlofpm` (`entryId`,`sortOrder`),
  CONSTRAINT `fk_ftouotrniegxjqkaswynsozkgcmdolvipnlg` FOREIGN KEY (`entryId`) REFERENCES `entries` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_putdbjnbluhzjpseidadtdhqiwbfvryyihzf` FOREIGN KEY (`authorId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entries_authors`
--

LOCK TABLES `entries_authors` WRITE;
/*!40000 ALTER TABLE `entries_authors` DISABLE KEYS */;
/*!40000 ALTER TABLE `entries_authors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entrytypes`
--

DROP TABLE IF EXISTS `entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `entrytypes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `hasTitleField` tinyint(1) NOT NULL DEFAULT '1',
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `titleFormat` varchar(255) DEFAULT NULL,
  `showSlugField` tinyint(1) DEFAULT '1',
  `slugTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `slugTranslationKeyFormat` text,
  `showStatusField` tinyint(1) DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_lydmgghnpiggjjycaehpbjbqyoiiwgsctqrj` (`fieldLayoutId`),
  KEY `idx_lsdnohnypqeewvramfxzkndkuhlklnlxfget` (`dateDeleted`),
  CONSTRAINT `fk_vpjubvzihrkslphgopnoqonitpxfxncemiji` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entrytypes`
--

LOCK TABLES `entrytypes` WRITE;
/*!40000 ALTER TABLE `entrytypes` DISABLE KEYS */;
INSERT INTO `entrytypes` VALUES (1,1,'Home','home','house','blue',1,'site',NULL,'',1,'site',NULL,1,'2024-05-02 12:35:10','2024-05-02 12:35:10',NULL,'f353af18-96fc-4a3f-9c95-586303d02d2c'),(2,3,'About','about','user','red',1,'site',NULL,'',1,'site',NULL,1,'2024-05-02 13:11:00','2024-05-02 13:11:00',NULL,'dc56cc87-678f-4d74-a517-414aba78a3b2');
/*!40000 ALTER TABLE `entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldlayouts`
--

DROP TABLE IF EXISTS `fieldlayouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldlayouts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `config` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_kegxdspvcvaeyjtzikzbmpurrlyjxkjxmqbl` (`dateDeleted`),
  KEY `idx_mdzfmkdrtfnmvifebbdfccflyvhlhvrnibnj` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldlayouts`
--

LOCK TABLES `fieldlayouts` WRITE;
/*!40000 ALTER TABLE `fieldlayouts` DISABLE KEYS */;
INSERT INTO `fieldlayouts` VALUES (1,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"4ce23293-4586-4d8e-9876-87875f5e0434\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"0be1431f-c3d2-4ff0-bdbc-f88c62231252\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"3c1e13ab-a927-4726-a034-0fa67104053a\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"1d47ddfe-72ec-4111-b1cd-3caa343d172b\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-02 12:35:10','2024-05-02 12:51:05',NULL,'0bf46b84-d688-4584-b5c2-0863d3e37e54'),(2,'craft\\elements\\Asset','{\"tabs\": [{\"uid\": \"80ee1746-a341-40fa-95ce-516e3167e55f\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"333f6bd4-366b-4585-905b-96afbabf3deb\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-02 12:48:55','2024-05-02 12:48:55',NULL,'9b684ff8-e902-407f-9975-31abdcfe5e47'),(3,'craft\\elements\\Entry','{\"tabs\": [{\"uid\": \"21132f38-dc04-4fe9-99d5-8059c030eb75\", \"name\": \"Content\", \"elements\": [{\"id\": null, \"max\": null, \"min\": null, \"tip\": null, \"uid\": \"2ba58f3e-5fc7-48bb-95cc-204929aaaa18\", \"name\": null, \"size\": null, \"step\": null, \"type\": \"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\", \"class\": null, \"label\": null, \"title\": null, \"width\": 100, \"warning\": null, \"disabled\": false, \"readonly\": false, \"inputType\": null, \"requirable\": false, \"autocorrect\": true, \"orientation\": null, \"placeholder\": null, \"autocomplete\": false, \"instructions\": null, \"userCondition\": null, \"autocapitalize\": true, \"includeInCards\": false, \"providesThumbs\": false, \"labelAttributes\": [], \"elementCondition\": null, \"containerAttributes\": [], \"inputContainerAttributes\": []}, {\"tip\": null, \"uid\": \"5e2a9b23-1058-45d7-90bd-c052aca2b00b\", \"type\": \"craft\\\\fieldlayoutelements\\\\CustomField\", \"label\": null, \"width\": 100, \"handle\": null, \"warning\": null, \"fieldUid\": \"1d47ddfe-72ec-4111-b1cd-3caa343d172b\", \"required\": false, \"instructions\": null, \"userCondition\": null, \"includeInCards\": false, \"providesThumbs\": false, \"elementCondition\": null}], \"userCondition\": null, \"elementCondition\": null}]}','2024-05-02 13:11:00','2024-05-02 13:11:00',NULL,'4a7db94a-bd60-4fb0-8078-fa883173d225');
/*!40000 ALTER TABLE `fieldlayouts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fields`
--

DROP TABLE IF EXISTS `fields`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `handle` varchar(64) NOT NULL,
  `context` varchar(255) NOT NULL DEFAULT 'global',
  `columnSuffix` char(8) DEFAULT NULL,
  `instructions` text,
  `searchable` tinyint(1) NOT NULL DEFAULT '1',
  `translationMethod` varchar(255) NOT NULL DEFAULT 'none',
  `translationKeyFormat` text,
  `type` varchar(255) NOT NULL,
  `settings` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ebutxzbceiiwqdudtuyhltzrdkchtwjmxszo` (`handle`,`context`),
  KEY `idx_dqzhhetdgzjguvdvrxrgghawkdrzlfjhtdfe` (`context`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fields`
--

LOCK TABLES `fields` WRITE;
/*!40000 ALTER TABLE `fields` DISABLE KEYS */;
INSERT INTO `fields` VALUES (1,'Logo','logo','global',NULL,NULL,1,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":1,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Voeg Logo toe\",\"showCardsInGrid\":false,\"showSiteMenu\":false,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-05-02 12:50:39','2024-05-02 12:50:39','1d47ddfe-72ec-4111-b1cd-3caa343d172b'),(2,'Fotos','fotos','global',NULL,NULL,0,'site',NULL,'craft\\fields\\Assets','{\"allowSelfRelations\":false,\"allowSubfolders\":false,\"allowUploads\":true,\"allowedKinds\":[\"image\"],\"branchLimit\":null,\"defaultUploadLocationSource\":\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\",\"defaultUploadLocationSubpath\":null,\"localizeRelations\":false,\"maintainHierarchy\":false,\"maxRelations\":null,\"minRelations\":1,\"previewMode\":\"full\",\"restrictFiles\":true,\"restrictLocation\":false,\"restrictedDefaultUploadSubpath\":null,\"restrictedLocationSource\":\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\",\"restrictedLocationSubpath\":null,\"selectionLabel\":\"Voeg een foto toe.\",\"showCardsInGrid\":false,\"showSiteMenu\":true,\"showUnpermittedFiles\":false,\"showUnpermittedVolumes\":false,\"sources\":[\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\"],\"targetSiteId\":null,\"validateRelatedElements\":false,\"viewMode\":\"list\"}','2024-05-02 13:32:37','2024-05-02 13:34:50','5a45df4e-9a9d-4d13-9a73-62265aafe1d4'),(3,'productBeschrijving','productbeschrijving','global',NULL,NULL,0,'none',NULL,'craft\\fields\\PlainText','{\"byteLimit\":null,\"charLimit\":null,\"code\":false,\"initialRows\":3,\"multiline\":true,\"placeholder\":null,\"uiMode\":\"normal\"}','2024-05-02 13:34:22','2024-05-02 13:34:22','67215269-f89c-4e18-afb6-1bd0c79a3280'),(4,'Prijs','prijs','global',NULL,NULL,0,'none',NULL,'craft\\fields\\Money','{\"currency\":\"EUR\",\"defaultValue\":null,\"max\":null,\"min\":0,\"showCurrency\":true,\"size\":null}','2024-05-02 13:35:23','2024-05-02 13:35:23','0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9');
/*!40000 ALTER TABLE `fields` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `globalsets`
--

DROP TABLE IF EXISTS `globalsets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `globalsets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vjqmnqqfyvekuxwkhcitfktohndqlwbepohw` (`name`),
  KEY `idx_xuzlxdanxfwouzjpswkbiutieoyeugwrwrri` (`handle`),
  KEY `idx_uxffgeemzivmuafzavtxpusjuyeuntglnyaz` (`fieldLayoutId`),
  KEY `idx_qllzadnnyjibmqjfagnexfllhsyzcdidifrl` (`sortOrder`),
  CONSTRAINT `fk_bprxppcaayvpjtbrqhgggnjsjsapubzyqybz` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_clqnotmutmrgolxlfscdgnljrfdfzrpknfqx` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `globalsets`
--

LOCK TABLES `globalsets` WRITE;
/*!40000 ALTER TABLE `globalsets` DISABLE KEYS */;
/*!40000 ALTER TABLE `globalsets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqlschemas`
--

DROP TABLE IF EXISTS `gqlschemas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqlschemas` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `scope` json DEFAULT NULL,
  `isPublic` tinyint(1) NOT NULL DEFAULT '0',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqlschemas`
--

LOCK TABLES `gqlschemas` WRITE;
/*!40000 ALTER TABLE `gqlschemas` DISABLE KEYS */;
INSERT INTO `gqlschemas` VALUES (1,'Public Schema','[]',1,'2024-05-02 13:08:01','2024-05-02 13:08:01','56a88afc-1100-4ee0-8f36-380a2e7fdc28');
/*!40000 ALTER TABLE `gqlschemas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gqltokens`
--

DROP TABLE IF EXISTS `gqltokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `gqltokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `accessToken` varchar(255) NOT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `expiryDate` datetime DEFAULT NULL,
  `lastUsed` datetime DEFAULT NULL,
  `schemaId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xyhakkyvchtcpzypusarhwbyqtfpdhmprgsz` (`accessToken`),
  UNIQUE KEY `idx_vwrmwbzmejbmyvwfpfrwrlephguzbjrkngmb` (`name`),
  KEY `fk_qafrlxpgzzrajajycgsungpaciuiubiwtern` (`schemaId`),
  CONSTRAINT `fk_qafrlxpgzzrajajycgsungpaciuiubiwtern` FOREIGN KEY (`schemaId`) REFERENCES `gqlschemas` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gqltokens`
--

LOCK TABLES `gqltokens` WRITE;
/*!40000 ALTER TABLE `gqltokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `gqltokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransformindex`
--

DROP TABLE IF EXISTS `imagetransformindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransformindex` (
  `id` int NOT NULL AUTO_INCREMENT,
  `assetId` int NOT NULL,
  `transformer` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `transformString` varchar(255) NOT NULL,
  `fileExists` tinyint(1) NOT NULL DEFAULT '0',
  `inProgress` tinyint(1) NOT NULL DEFAULT '0',
  `error` tinyint(1) NOT NULL DEFAULT '0',
  `dateIndexed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ozumbreiqihmlswalcdixskordyunsmazjtl` (`assetId`,`transformString`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransformindex`
--

LOCK TABLES `imagetransformindex` WRITE;
/*!40000 ALTER TABLE `imagetransformindex` DISABLE KEYS */;
INSERT INTO `imagetransformindex` VALUES (5,7,'craft\\imagetransforms\\ImageTransformer','Illustrashop.png',NULL,'_30x6_crop_center-center_none',1,0,0,'2024-05-02 12:57:28','2024-05-02 12:57:28','2024-05-02 12:57:54','fa8eaf7d-97b4-4c84-ba8e-92e822f37682'),(6,7,'craft\\imagetransforms\\ImageTransformer','Illustrashop.png',NULL,'_60x13_crop_center-center_none',1,0,0,'2024-05-02 12:57:28','2024-05-02 12:57:28','2024-05-02 12:57:28','0a776a54-d84d-4469-83f7-3855438396c6'),(7,12,'craft\\imagetransforms\\ImageTransformer','Illustration1.png',NULL,'_15x30_crop_center-center_none',1,0,0,'2024-05-02 13:11:14','2024-05-02 13:11:14','2024-05-02 13:11:14','9e2b8329-7f11-4a86-b08f-281d36544ee0'),(8,12,'craft\\imagetransforms\\ImageTransformer','Illustration1.png',NULL,'_31x60_crop_center-center_none',1,0,0,'2024-05-02 13:11:14','2024-05-02 13:11:14','2024-05-02 13:11:14','4eb68574-bb8c-40ae-8fb4-fcfeb64c3ee1');
/*!40000 ALTER TABLE `imagetransformindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imagetransforms`
--

DROP TABLE IF EXISTS `imagetransforms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `imagetransforms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `mode` enum('stretch','fit','crop','letterbox') NOT NULL DEFAULT 'crop',
  `position` enum('top-left','top-center','top-right','center-left','center-center','center-right','bottom-left','bottom-center','bottom-right') NOT NULL DEFAULT 'center-center',
  `width` int unsigned DEFAULT NULL,
  `height` int unsigned DEFAULT NULL,
  `format` varchar(255) DEFAULT NULL,
  `quality` int DEFAULT NULL,
  `interlace` enum('none','line','plane','partition') NOT NULL DEFAULT 'none',
  `fill` varchar(11) DEFAULT NULL,
  `upscale` tinyint(1) NOT NULL DEFAULT '1',
  `parameterChangeTime` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_nawgyttmkjbtcklunrqcqkfimqfmmklvzrsa` (`name`),
  KEY `idx_xrtqwaegfudawwtwovwrbzybyrgsjmkbzipq` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `imagetransforms`
--

LOCK TABLES `imagetransforms` WRITE;
/*!40000 ALTER TABLE `imagetransforms` DISABLE KEYS */;
/*!40000 ALTER TABLE `imagetransforms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `info`
--

DROP TABLE IF EXISTS `info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `info` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `schemaVersion` varchar(15) NOT NULL,
  `maintenance` tinyint(1) NOT NULL DEFAULT '0',
  `configVersion` char(12) NOT NULL DEFAULT '000000000000',
  `fieldVersion` char(12) NOT NULL DEFAULT '000000000000',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info`
--

LOCK TABLES `info` WRITE;
/*!40000 ALTER TABLE `info` DISABLE KEYS */;
INSERT INTO `info` VALUES (1,'5.0.6','5.0.0.20',0,'cbgskanmkuck','3@htuzzxagdf','2024-04-30 12:49:40','2024-05-02 13:35:23','82fface9-dfce-44c6-8877-e8a1a8ced07f');
/*!40000 ALTER TABLE `info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `track` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applyTime` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lcfxrcvavvrxiqajapbxekzyqjemvjpkorve` (`track`,`name`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'craft','Install','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','33cead37-3792-4bea-877f-e78be7c2aea8'),(2,'craft','m221101_115859_create_entries_authors_table','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','d9ebdcd4-52dd-4ad6-aaac-90659677d894'),(3,'craft','m221107_112121_add_max_authors_to_sections','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','f96e3c0f-f750-4703-930c-0e24b3ed4bd9'),(4,'craft','m221205_082005_translatable_asset_alt_text','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','7a0cd374-dcf6-4729-be68-b6e6c28ee6ce'),(5,'craft','m230314_110309_add_authenticator_table','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','6ed28642-62bf-46a5-aa7e-0f51289fdcc8'),(6,'craft','m230314_111234_add_webauthn_table','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','6e74c636-f2a7-441d-8f91-218c01c976f3'),(7,'craft','m230503_120303_add_recoverycodes_table','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','3f8a1a88-9057-403f-946c-37af7bd78558'),(8,'craft','m230511_000000_field_layout_configs','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','764ee64c-ad33-4fd1-8a1f-4199005f9167'),(9,'craft','m230511_215903_content_refactor','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','4abc3b6e-a125-4d06-9ec3-8cb57e392845'),(10,'craft','m230524_000000_add_entry_type_show_slug_field','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','be8782a2-0048-492b-8250-2dd40bdd5b5c'),(11,'craft','m230524_000001_entry_type_icons','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','c28516cd-15b2-4640-a7d3-49c2e1af43c0'),(12,'craft','m230524_000002_entry_type_colors','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','5fa626f3-11c4-44d2-b2b9-45cbb64f6bbf'),(13,'craft','m230524_220029_global_entry_types','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','18c07be1-ca89-4852-a3f0-791224845163'),(14,'craft','m230531_123004_add_entry_type_show_status_field','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','8a78e9f7-36fd-467c-8ed0-31a976c2f210'),(15,'craft','m230607_102049_add_entrytype_slug_translation_columns','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','c44ccf03-94b5-428c-9cf1-9204b583c896'),(16,'craft','m230616_173810_kill_field_groups','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','14161090-82e3-4c7d-80c3-607fdfde4735'),(17,'craft','m230616_183820_remove_field_name_limit','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','764f0007-d292-4a06-befa-f22ed20bedc0'),(18,'craft','m230617_070415_entrify_matrix_blocks','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','c571ca11-bb4a-4bc5-811c-a7d65af15894'),(19,'craft','m230710_162700_element_activity','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','7cc2fc24-b537-43ae-b6d8-9f6113f91fce'),(20,'craft','m230820_162023_fix_cache_id_type','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','a5193137-2e84-4964-aa4e-0b8b03d9e4b2'),(21,'craft','m230826_094050_fix_session_id_type','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','a7862abf-c2a3-4746-a7d3-c57c5393e6bb'),(22,'craft','m230904_190356_address_fields','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','3cdbb0ec-24b1-4303-9ca5-1e51be45e095'),(23,'craft','m230928_144045_add_subpath_to_volumes','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','1daf7412-05c4-44e8-bf7a-60379a78936d'),(24,'craft','m231013_185640_changedfields_amend_primary_key','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','3dcb2be4-5078-43c3-a575-b34b43073e30'),(25,'craft','m231213_030600_element_bulk_ops','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','959b4d92-6779-4f9a-a8b8-ca2907afbddc'),(26,'craft','m240129_150719_sites_language_amend_length','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','77b42f33-eda1-40ec-957d-e1cd003104fa'),(27,'craft','m240206_035135_convert_json_columns','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','f03fc3b8-86c0-43d3-8da3-092e368a3e83'),(28,'craft','m240207_182452_address_line_3','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','004fabad-cfc9-47f2-9453-6b2fc7d7cabc'),(29,'craft','m240302_212719_solo_preview_targets','2024-04-30 12:49:40','2024-04-30 12:49:40','2024-04-30 12:49:40','9be8f2e7-507c-48d1-8e4b-9564cc0a3d6a');
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `plugins`
--

DROP TABLE IF EXISTS `plugins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `plugins` (
  `id` int NOT NULL AUTO_INCREMENT,
  `handle` varchar(255) NOT NULL,
  `version` varchar(255) NOT NULL,
  `schemaVersion` varchar(255) NOT NULL,
  `installDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_kssitdhiwtqstefcavhzqqjaqyneueiueiyh` (`handle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `plugins`
--

LOCK TABLES `plugins` WRITE;
/*!40000 ALTER TABLE `plugins` DISABLE KEYS */;
/*!40000 ALTER TABLE `plugins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projectconfig`
--

DROP TABLE IF EXISTS `projectconfig`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projectconfig` (
  `path` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`path`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projectconfig`
--

LOCK TABLES `projectconfig` WRITE;
/*!40000 ALTER TABLE `projectconfig` DISABLE KEYS */;
INSERT INTO `projectconfig` VALUES ('dateModified','1714656923'),('email.fromEmail','\"nathan.ddk@outlook.com\"'),('email.fromName','\"Illustrashop\"'),('email.transportType','\"craft\\\\mail\\\\transportadapters\\\\Sendmail\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.color','\"red\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elementCondition','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.autocapitalize','true'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.autocomplete','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.autocorrect','true'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.class','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.disabled','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.elementCondition','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.id','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.includeInCards','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.inputType','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.instructions','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.label','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.max','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.min','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.name','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.orientation','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.placeholder','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.providesThumbs','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.readonly','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.requirable','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.size','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.step','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.tip','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.title','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.uid','\"2ba58f3e-5fc7-48bb-95cc-204929aaaa18\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.userCondition','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.warning','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.0.width','100'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.elementCondition','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.fieldUid','\"1d47ddfe-72ec-4111-b1cd-3caa343d172b\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.handle','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.includeInCards','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.instructions','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.label','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.providesThumbs','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.required','false'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.tip','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.uid','\"5e2a9b23-1058-45d7-90bd-c052aca2b00b\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.userCondition','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.warning','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.elements.1.width','100'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.name','\"Content\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.uid','\"21132f38-dc04-4fe9-99d5-8059c030eb75\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.fieldLayouts.4a7db94a-bd60-4fb0-8078-fa883173d225.tabs.0.userCondition','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.handle','\"about\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.hasTitleField','true'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.icon','\"user\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.name','\"About\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.showSlugField','true'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.showStatusField','true'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.slugTranslationKeyFormat','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.slugTranslationMethod','\"site\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.titleFormat','\"\"'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.titleTranslationKeyFormat','null'),('entryTypes.dc56cc87-678f-4d74-a517-414aba78a3b2.titleTranslationMethod','\"site\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.color','\"blue\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elementCondition','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.autocapitalize','true'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.autocomplete','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.autocorrect','true'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.class','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.disabled','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.elementCondition','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.id','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.includeInCards','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.inputType','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.instructions','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.label','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.max','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.min','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.name','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.orientation','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.placeholder','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.providesThumbs','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.readonly','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.requirable','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.size','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.step','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.tip','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.title','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\entries\\\\EntryTitleField\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.uid','\"0be1431f-c3d2-4ff0-bdbc-f88c62231252\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.userCondition','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.warning','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.0.width','100'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.elementCondition','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.fieldUid','\"1d47ddfe-72ec-4111-b1cd-3caa343d172b\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.handle','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.includeInCards','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.instructions','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.label','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.providesThumbs','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.required','false'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.tip','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.type','\"craft\\\\fieldlayoutelements\\\\CustomField\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.uid','\"3c1e13ab-a927-4726-a034-0fa67104053a\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.userCondition','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.warning','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.elements.1.width','100'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.name','\"Content\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.uid','\"4ce23293-4586-4d8e-9876-87875f5e0434\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.fieldLayouts.0bf46b84-d688-4584-b5c2-0863d3e37e54.tabs.0.userCondition','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.handle','\"home\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.hasTitleField','true'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.icon','\"house\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.name','\"Home\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.showSlugField','true'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.showStatusField','true'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.slugTranslationKeyFormat','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.slugTranslationMethod','\"site\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.titleFormat','\"\"'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.titleTranslationKeyFormat','null'),('entryTypes.f353af18-96fc-4a3f-9c95-586303d02d2c.titleTranslationMethod','\"site\"'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.columnSuffix','null'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.handle','\"prijs\"'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.instructions','null'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.name','\"Prijs\"'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.searchable','false'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.settings.currency','\"EUR\"'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.settings.defaultValue','null'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.settings.max','null'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.settings.min','0'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.settings.showCurrency','true'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.settings.size','null'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.translationKeyFormat','null'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.translationMethod','\"none\"'),('fields.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9.type','\"craft\\\\fields\\\\Money\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.columnSuffix','null'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.handle','\"logo\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.instructions','null'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.name','\"Logo\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.searchable','true'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.allowedKinds.0','\"image\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.allowSelfRelations','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.allowSubfolders','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.allowUploads','true'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.branchLimit','null'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.defaultUploadLocationSource','\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.defaultUploadLocationSubpath','null'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.localizeRelations','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.maintainHierarchy','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.maxRelations','1'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.minRelations','1'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.previewMode','\"full\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.restrictedDefaultUploadSubpath','null'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.restrictedLocationSource','\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.restrictedLocationSubpath','null'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.restrictFiles','true'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.restrictLocation','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.selectionLabel','\"Voeg Logo toe\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.showCardsInGrid','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.showSiteMenu','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.showUnpermittedFiles','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.showUnpermittedVolumes','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.sources.0','\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.targetSiteId','null'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.validateRelatedElements','false'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.settings.viewMode','\"list\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.translationKeyFormat','null'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.translationMethod','\"site\"'),('fields.1d47ddfe-72ec-4111-b1cd-3caa343d172b.type','\"craft\\\\fields\\\\Assets\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.columnSuffix','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.handle','\"fotos\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.instructions','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.name','\"Fotos\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.searchable','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.allowedKinds.0','\"image\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.allowSelfRelations','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.allowSubfolders','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.allowUploads','true'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.branchLimit','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.defaultUploadLocationSource','\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.defaultUploadLocationSubpath','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.localizeRelations','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.maintainHierarchy','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.maxRelations','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.minRelations','1'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.previewMode','\"full\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.restrictedDefaultUploadSubpath','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.restrictedLocationSource','\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.restrictedLocationSubpath','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.restrictFiles','true'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.restrictLocation','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.selectionLabel','\"Voeg een foto toe.\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.showCardsInGrid','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.showSiteMenu','true'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.showUnpermittedFiles','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.showUnpermittedVolumes','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.sources.0','\"volume:86945d3a-9e49-4245-b5cf-e27ed83e8f76\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.targetSiteId','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.validateRelatedElements','false'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.settings.viewMode','\"list\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.translationKeyFormat','null'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.translationMethod','\"site\"'),('fields.5a45df4e-9a9d-4d13-9a73-62265aafe1d4.type','\"craft\\\\fields\\\\Assets\"'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.columnSuffix','null'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.handle','\"productbeschrijving\"'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.instructions','null'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.name','\"productBeschrijving\"'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.searchable','false'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.settings.byteLimit','null'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.settings.charLimit','null'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.settings.code','false'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.settings.initialRows','3'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.settings.multiline','true'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.settings.placeholder','null'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.settings.uiMode','\"normal\"'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.translationKeyFormat','null'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.translationMethod','\"none\"'),('fields.67215269-f89c-4e18-afb6-1bd0c79a3280.type','\"craft\\\\fields\\\\PlainText\"'),('fs.images.hasUrls','true'),('fs.images.name','\"Images\"'),('fs.images.settings.path','\"@webroot/images\"'),('fs.images.type','\"craft\\\\fs\\\\Local\"'),('fs.images.url','\"/images\"'),('graphql.schemas.56a88afc-1100-4ee0-8f36-380a2e7fdc28.isPublic','true'),('graphql.schemas.56a88afc-1100-4ee0-8f36-380a2e7fdc28.name','\"Public Schema\"'),('meta.__names__.0c71f84b-b6dc-4f7c-b27a-0e0ec496e0b9','\"Prijs\"'),('meta.__names__.1d47ddfe-72ec-4111-b1cd-3caa343d172b','\"Logo\"'),('meta.__names__.347620c5-2d4f-42f5-8745-b16fff55dec6','\"Home\"'),('meta.__names__.4a826233-2673-4533-bdf4-5dd6f0487adc','\"Illustrashop\"'),('meta.__names__.56a88afc-1100-4ee0-8f36-380a2e7fdc28','\"Public Schema\"'),('meta.__names__.5a45df4e-9a9d-4d13-9a73-62265aafe1d4','\"Fotos\"'),('meta.__names__.67215269-f89c-4e18-afb6-1bd0c79a3280','\"productBeschrijving\"'),('meta.__names__.86945d3a-9e49-4245-b5cf-e27ed83e8f76','\"Images\"'),('meta.__names__.b983c117-aebe-4dd5-92b8-5d0d49b48b82','\"Illustrashop\"'),('meta.__names__.dc56cc87-678f-4d74-a517-414aba78a3b2','\"About\"'),('meta.__names__.f353af18-96fc-4a3f-9c95-586303d02d2c','\"Home\"'),('meta.__names__.fdb40e6b-86d1-45a0-9ff2-85269d1d1550','\"About\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.defaultPlacement','\"end\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.enableVersioning','true'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.entryTypes.0','\"f353af18-96fc-4a3f-9c95-586303d02d2c\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.handle','\"home\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.maxAuthors','1'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.name','\"Home\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.propagationMethod','\"all\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.siteSettings.4a826233-2673-4533-bdf4-5dd6f0487adc.enabledByDefault','true'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.siteSettings.4a826233-2673-4533-bdf4-5dd6f0487adc.hasUrls','true'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.siteSettings.4a826233-2673-4533-bdf4-5dd6f0487adc.template','\"home.twig\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.siteSettings.4a826233-2673-4533-bdf4-5dd6f0487adc.uriFormat','\"__home__\"'),('sections.347620c5-2d4f-42f5-8745-b16fff55dec6.type','\"single\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.defaultPlacement','\"end\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.enableVersioning','true'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.entryTypes.0','\"dc56cc87-678f-4d74-a517-414aba78a3b2\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.handle','\"about\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.maxAuthors','1'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.name','\"About\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.previewTargets.0.__assoc__.0.0','\"label\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.previewTargets.0.__assoc__.0.1','\"Primary entry page\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.previewTargets.0.__assoc__.1.0','\"urlFormat\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.previewTargets.0.__assoc__.1.1','\"{url}\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.previewTargets.0.__assoc__.2.0','\"refresh\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.previewTargets.0.__assoc__.2.1','\"1\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.propagationMethod','\"all\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.siteSettings.4a826233-2673-4533-bdf4-5dd6f0487adc.enabledByDefault','true'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.siteSettings.4a826233-2673-4533-bdf4-5dd6f0487adc.hasUrls','true'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.siteSettings.4a826233-2673-4533-bdf4-5dd6f0487adc.template','\"about/_entry\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.siteSettings.4a826233-2673-4533-bdf4-5dd6f0487adc.uriFormat','\"about\"'),('sections.fdb40e6b-86d1-45a0-9ff2-85269d1d1550.type','\"single\"'),('siteGroups.b983c117-aebe-4dd5-92b8-5d0d49b48b82.name','\"Illustrashop\"'),('sites.4a826233-2673-4533-bdf4-5dd6f0487adc.baseUrl','\"$PRIMARY_SITE_URL\"'),('sites.4a826233-2673-4533-bdf4-5dd6f0487adc.handle','\"default\"'),('sites.4a826233-2673-4533-bdf4-5dd6f0487adc.hasUrls','true'),('sites.4a826233-2673-4533-bdf4-5dd6f0487adc.language','\"en-US\"'),('sites.4a826233-2673-4533-bdf4-5dd6f0487adc.name','\"Illustrashop\"'),('sites.4a826233-2673-4533-bdf4-5dd6f0487adc.primary','true'),('sites.4a826233-2673-4533-bdf4-5dd6f0487adc.siteGroup','\"b983c117-aebe-4dd5-92b8-5d0d49b48b82\"'),('sites.4a826233-2673-4533-bdf4-5dd6f0487adc.sortOrder','1'),('system.edition','\"solo\"'),('system.live','true'),('system.name','\"Illustrashop\"'),('system.schemaVersion','\"5.0.0.20\"'),('system.timeZone','\"America/Los_Angeles\"'),('users.allowPublicRegistration','false'),('users.defaultGroup','null'),('users.photoSubpath','null'),('users.photoVolumeUid','null'),('users.require2fa','false'),('users.requireEmailVerification','true'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.altTranslationKeyFormat','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.altTranslationMethod','\"none\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elementCondition','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.autocapitalize','true'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.autocomplete','false'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.autocorrect','true'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.class','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.disabled','false'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.elementCondition','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.id','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.includeInCards','false'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.inputType','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.instructions','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.label','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.max','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.min','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.name','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.orientation','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.placeholder','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.providesThumbs','false'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.readonly','false'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.requirable','false'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.size','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.step','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.tip','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.title','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.type','\"craft\\\\fieldlayoutelements\\\\assets\\\\AssetTitleField\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.uid','\"333f6bd4-366b-4585-905b-96afbabf3deb\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.userCondition','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.warning','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.elements.0.width','100'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.name','\"Content\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.uid','\"80ee1746-a341-40fa-95ce-516e3167e55f\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fieldLayouts.9b684ff8-e902-407f-9975-31abdcfe5e47.tabs.0.userCondition','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.fs','\"images\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.handle','\"images\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.name','\"Images\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.sortOrder','1'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.subpath','\"\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.titleTranslationKeyFormat','null'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.titleTranslationMethod','\"site\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.transformFs','\"\"'),('volumes.86945d3a-9e49-4245-b5cf-e27ed83e8f76.transformSubpath','\"\"');
/*!40000 ALTER TABLE `projectconfig` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `queue`
--

DROP TABLE IF EXISTS `queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `channel` varchar(255) NOT NULL DEFAULT 'queue',
  `job` longblob NOT NULL,
  `description` text,
  `timePushed` int NOT NULL,
  `ttr` int NOT NULL,
  `delay` int NOT NULL DEFAULT '0',
  `priority` int unsigned NOT NULL DEFAULT '1024',
  `dateReserved` datetime DEFAULT NULL,
  `timeUpdated` int DEFAULT NULL,
  `progress` smallint NOT NULL DEFAULT '0',
  `progressLabel` varchar(255) DEFAULT NULL,
  `attempt` int DEFAULT NULL,
  `fail` tinyint(1) DEFAULT '0',
  `dateFailed` datetime DEFAULT NULL,
  `error` text,
  PRIMARY KEY (`id`),
  KEY `idx_vikkrernpiipysrtlqoxguyyrugmoopaqpfr` (`channel`,`fail`,`timeUpdated`,`timePushed`),
  KEY `idx_jzyatztbzbncxtwoklbjeixaxfxmejxkocne` (`channel`,`fail`,`timeUpdated`,`delay`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `queue`
--

LOCK TABLES `queue` WRITE;
/*!40000 ALTER TABLE `queue` DISABLE KEYS */;
/*!40000 ALTER TABLE `queue` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recoverycodes`
--

DROP TABLE IF EXISTS `recoverycodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `recoverycodes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `recoveryCodes` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recoverycodes`
--

LOCK TABLES `recoverycodes` WRITE;
/*!40000 ALTER TABLE `recoverycodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `recoverycodes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `relations`
--

DROP TABLE IF EXISTS `relations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `relations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldId` int NOT NULL,
  `sourceId` int NOT NULL,
  `sourceSiteId` int DEFAULT NULL,
  `targetId` int NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lnpgzrppnvtmjkeghujtahhpviskkjsbjnwk` (`fieldId`,`sourceId`,`sourceSiteId`,`targetId`),
  KEY `idx_zovcxbsnutmygbqnmircpvowcezzzfrfaurv` (`sourceId`),
  KEY `idx_qwvdfncjwgnzopmmchktvmbkvqutewufeeou` (`targetId`),
  KEY `idx_zacqomgattznvdezwdghpxxfsaxopobmyydc` (`sourceSiteId`),
  CONSTRAINT `fk_egmljohmjnxviayvtagfdactywowtoqosake` FOREIGN KEY (`sourceSiteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_jowbnzhdptcwdboxguzbxszqhjjepnhehjec` FOREIGN KEY (`fieldId`) REFERENCES `fields` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_qfwfntsfgxitcqqrspubxxbgzsxdlxwbmalk` FOREIGN KEY (`sourceId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `relations`
--

LOCK TABLES `relations` WRITE;
/*!40000 ALTER TABLE `relations` DISABLE KEYS */;
INSERT INTO `relations` VALUES (3,1,6,NULL,4,1,'2024-05-02 12:51:45','2024-05-02 12:51:45','7ff2854e-8098-4414-8787-e89875a8a7a4'),(5,1,2,NULL,7,1,'2024-05-02 12:58:06','2024-05-02 12:58:06','f6e7cac3-9c52-4757-a299-c8e72114b783'),(6,1,9,NULL,7,1,'2024-05-02 12:58:06','2024-05-02 12:58:06','520238b3-7dd1-45ae-82a6-6f822f452e1c'),(8,1,10,NULL,12,1,'2024-05-02 13:11:17','2024-05-02 13:11:17','6b7dcf00-0b72-4372-bf83-85e7e0e69af4'),(9,1,14,NULL,12,1,'2024-05-02 13:11:17','2024-05-02 13:11:17','7123e6ff-7c27-4ceb-8b09-5713bebddb91');
/*!40000 ALTER TABLE `relations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `resourcepaths`
--

DROP TABLE IF EXISTS `resourcepaths`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resourcepaths` (
  `hash` varchar(255) NOT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resourcepaths`
--

LOCK TABLES `resourcepaths` WRITE;
/*!40000 ALTER TABLE `resourcepaths` DISABLE KEYS */;
INSERT INTO `resourcepaths` VALUES ('14b7bcea','@craft/web/assets/d3/dist'),('14fc4332','@craft/web/assets/updateswidget/dist'),('19bf606b','@craft/web/assets/fieldsettings/dist'),('1fd6b55d','@craft/web/assets/iframeresizer/dist'),('29c16908','@craft/web/assets/conditionbuilder/dist'),('2a46015c','@craft/web/assets/recententries/dist'),('2ca38eb','@craft/web/assets/selectize/dist'),('32b39405','@craft/web/assets/axios/dist'),('3fec175','@craft/web/assets/installer/dist'),('445a3457','@craft/web/assets/fabric/dist'),('5470a269','@craft/web/assets/utilities/dist'),('5df82c9','@craft/web/assets/tailwindreset/dist'),('6ce80340','@craft/web/assets/garnish/dist'),('78df3efb','@craft/web/assets/focalpoint/dist'),('7d6640bf','@craft/web/assets/admintable/dist'),('83400796','@craft/web/assets/velocity/dist'),('8684da43','@craft/web/assets/jquerytouchevents/dist'),('86d70521','@craft/web/assets/jquerypayment/dist'),('88dc8ce6','@craft/web/assets/datepickeri18n/dist'),('8c45887f','@craft/web/assets/feed/dist'),('97382f92','@craft/web/assets/editsection/dist'),('9760dfcd','@craft/web/assets/vue/dist'),('b13462ff','@craft/web/assets/xregexp/dist'),('b350b53b','@craft/web/assets/craftsupport/dist'),('ba8cdfff','@craft/web/assets/picturefill/dist'),('c4e5e854','@craft/web/assets/fileupload/dist'),('cf6dcb3d','@craft/web/assets/prismjs/dist'),('d079aee9','@bower/jquery/dist'),('d599b101','@craft/web/assets/elementresizedetector/dist'),('da9e3eff','@craft/web/assets/jqueryui/dist'),('e1d02c3b','@craft/web/assets/htmx/dist'),('e829aa3','@craft/web/assets/cp/dist'),('f506aeb4','@craft/web/assets/dashboard/dist');
/*!40000 ALTER TABLE `resourcepaths` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `revisions`
--

DROP TABLE IF EXISTS `revisions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `revisions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `canonicalId` int NOT NULL,
  `creatorId` int DEFAULT NULL,
  `num` int NOT NULL,
  `notes` text,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_nhxcuacxwwkblttdznyferjytyrqreqrcvss` (`canonicalId`,`num`),
  KEY `fk_dyxpbsjoucyemnwkixehbietjeiegyutsrut` (`creatorId`),
  CONSTRAINT `fk_dyxpbsjoucyemnwkixehbietjeiegyutsrut` FOREIGN KEY (`creatorId`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_lwycmtmcphxakgpmqdzghajvzqlcptkjufbt` FOREIGN KEY (`canonicalId`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `revisions`
--

LOCK TABLES `revisions` WRITE;
/*!40000 ALTER TABLE `revisions` DISABLE KEYS */;
INSERT INTO `revisions` VALUES (1,2,1,1,NULL),(2,2,1,2,'Applied “Draft 1”'),(3,2,1,3,'Applied “Draft 1”'),(4,10,1,1,NULL),(5,10,1,2,'Applied “Draft 1”');
/*!40000 ALTER TABLE `revisions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `searchindex`
--

DROP TABLE IF EXISTS `searchindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `searchindex` (
  `elementId` int NOT NULL,
  `attribute` varchar(25) NOT NULL,
  `fieldId` int NOT NULL,
  `siteId` int NOT NULL,
  `keywords` text NOT NULL,
  PRIMARY KEY (`elementId`,`attribute`,`fieldId`,`siteId`),
  FULLTEXT KEY `idx_xeizdonbenmhfoqppewgfdxzzkhiguuqcvsr` (`keywords`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `searchindex`
--

LOCK TABLES `searchindex` WRITE;
/*!40000 ALTER TABLE `searchindex` DISABLE KEYS */;
INSERT INTO `searchindex` VALUES (1,'email',0,1,' nathan ddk outlook com '),(1,'firstname',0,1,''),(1,'fullname',0,1,''),(1,'lastname',0,1,''),(1,'slug',0,1,''),(1,'username',0,1,' robbenathan '),(2,'field',1,1,' illustrashop '),(2,'slug',0,1,' home '),(2,'title',0,1,' home '),(4,'alt',0,1,''),(4,'extension',0,1,' png '),(4,'filename',0,1,' illustrashop png '),(4,'kind',0,1,' image '),(4,'slug',0,1,''),(4,'title',0,1,' illustrashop '),(7,'alt',0,1,''),(7,'extension',0,1,' png '),(7,'filename',0,1,' illustrashop png '),(7,'kind',0,1,' image '),(7,'slug',0,1,''),(7,'title',0,1,' illustrashop '),(10,'field',1,1,' illustration1 '),(10,'slug',0,1,' about '),(10,'title',0,1,' about '),(12,'alt',0,1,''),(12,'extension',0,1,' png '),(12,'filename',0,1,' illustration1 png '),(12,'kind',0,1,' image '),(12,'slug',0,1,''),(12,'title',0,1,' illustration1 ');
/*!40000 ALTER TABLE `searchindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections`
--

DROP TABLE IF EXISTS `sections`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `type` enum('single','channel','structure') NOT NULL DEFAULT 'channel',
  `enableVersioning` tinyint(1) NOT NULL DEFAULT '0',
  `maxAuthors` smallint unsigned NOT NULL DEFAULT '1',
  `propagationMethod` varchar(255) NOT NULL DEFAULT 'all',
  `defaultPlacement` enum('beginning','end') NOT NULL DEFAULT 'end',
  `previewTargets` json DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_gdiaykwoshmbacmnwbkrdxxqegsqxzhnpyjs` (`handle`),
  KEY `idx_uogzrqciaexrszxiffnwpwlxybqspexvlkjo` (`name`),
  KEY `idx_ctrfywtleajmihsnolorebfcysfnlhsnahjm` (`structureId`),
  KEY `idx_emrdrwbtbdvrkcwilcvyqubllzcenpdetszz` (`dateDeleted`),
  CONSTRAINT `fk_hxaazhblciumtnbmwugmcnufrrhphatjhxkz` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections`
--

LOCK TABLES `sections` WRITE;
/*!40000 ALTER TABLE `sections` DISABLE KEYS */;
INSERT INTO `sections` VALUES (1,NULL,'Home','home','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-05-02 12:35:20','2024-05-02 12:35:20',NULL,'347620c5-2d4f-42f5-8745-b16fff55dec6'),(2,NULL,'About','about','single',1,1,'all','end','[{\"label\": \"Primary entry page\", \"refresh\": \"1\", \"urlFormat\": \"{url}\"}]','2024-05-02 13:11:08','2024-05-02 13:11:08',NULL,'fdb40e6b-86d1-45a0-9ff2-85269d1d1550');
/*!40000 ALTER TABLE `sections` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_entrytypes`
--

DROP TABLE IF EXISTS `sections_entrytypes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_entrytypes` (
  `sectionId` int NOT NULL,
  `typeId` int NOT NULL,
  `sortOrder` smallint unsigned NOT NULL,
  PRIMARY KEY (`sectionId`,`typeId`),
  KEY `fk_diiaxykkuczwkjllczhwzihtzawbpzexqpmz` (`typeId`),
  CONSTRAINT `fk_diiaxykkuczwkjllczhwzihtzawbpzexqpmz` FOREIGN KEY (`typeId`) REFERENCES `entrytypes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kvrgvvvudpdzefjyjcxywetgpfyyguqagnqp` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_entrytypes`
--

LOCK TABLES `sections_entrytypes` WRITE;
/*!40000 ALTER TABLE `sections_entrytypes` DISABLE KEYS */;
INSERT INTO `sections_entrytypes` VALUES (1,1,1),(2,2,1);
/*!40000 ALTER TABLE `sections_entrytypes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sections_sites`
--

DROP TABLE IF EXISTS `sections_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sections_sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sectionId` int NOT NULL,
  `siteId` int NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '1',
  `uriFormat` text,
  `template` varchar(500) DEFAULT NULL,
  `enabledByDefault` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ckkjctfwffzjebyoosqwyfmvcnzoxyaxqhcj` (`sectionId`,`siteId`),
  KEY `idx_agakypbfnpyheohipiawurpoaptiooxxhdgo` (`siteId`),
  CONSTRAINT `fk_ryuoibweeepgqecrigcdewydrkkvsquoqozk` FOREIGN KEY (`siteId`) REFERENCES `sites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_sbqugmmgmunvbsfubhfpjqdxklgnenqffsls` FOREIGN KEY (`sectionId`) REFERENCES `sections` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sections_sites`
--

LOCK TABLES `sections_sites` WRITE;
/*!40000 ALTER TABLE `sections_sites` DISABLE KEYS */;
INSERT INTO `sections_sites` VALUES (1,1,1,1,'__home__','home.twig',1,'2024-05-02 12:35:20','2024-05-02 12:35:20','98c38423-efc4-4186-bb48-cd574305b52a'),(2,2,1,1,'about','about/_entry',1,'2024-05-02 13:11:08','2024-05-02 13:11:08','ad80de10-bd05-4954-bf59-5774df97435a');
/*!40000 ALTER TABLE `sections_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sequences`
--

DROP TABLE IF EXISTS `sequences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sequences` (
  `name` varchar(255) NOT NULL,
  `next` int unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sequences`
--

LOCK TABLES `sequences` WRITE;
/*!40000 ALTER TABLE `sequences` DISABLE KEYS */;
/*!40000 ALTER TABLE `sequences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `token` char(100) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_tchhibgsdqhwfwxesnooefdpchibyyybfiah` (`uid`),
  KEY `idx_vqavczeajjyqgnkbmzzyivzjyathtztjyfky` (`token`),
  KEY `idx_xieijzlqjkcgdxsdiknhxstuvlgzdehcfoic` (`dateUpdated`),
  KEY `idx_tgvakuozrlqkzexnvvuvxjkbkbdboykojdsn` (`userId`),
  CONSTRAINT `fk_wogiuabjndtsoqdeoymgdgauorhbdibyjlba` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (1,1,'FUA-9wdYtKdtNqM7W4JOmYzHJjccJQGOMT6w3y8tooP5U3iYZGvtqpQi7jXy4wmzHpcbQro__tI3emc2k1iujLyACIADaf1a2LJI','2024-04-30 12:50:06','2024-05-02 12:27:02','7e4b2017-d1be-4438-80f5-940f21c90d69'),(2,1,'3X3-Un8pUGF1iD2fcvr40caceMYP-BvUhd4k28k3xuIZ0zfNXUsCHrSSSgQZyBHBOGxa8MGZE67zwXki5uX_IXEKKfGYGsEy2Pjl','2024-05-02 12:27:02','2024-05-13 12:56:20','91fe7b0b-25f2-45f8-acdd-8fb82a70357c'),(3,1,'HMTvYYcybOpFbxhDn478FVdbFZyiO2OvJnUx_ud4Sm-u6Yh-7MLUhpsKeuTeG3j6S8IGEUz3UTVF45K_lwY_oEVlJGrCH0gcmRmN','2024-05-13 12:56:20','2024-05-13 12:59:41','83b83dca-6abf-4d72-b6c1-bc3d652cb77a'),(4,1,'hO6mBuMGwUG5Ak-UzAlCIOK2wmQID8v37CyqnVTAS6aio-U03a2QzTMpPZOMhY6pYzU7mOFCKJgkdlg1mT6FOfK52w9E4_hRIr2O','2024-05-13 12:59:41','2024-05-13 13:01:02','3d3fa0f8-ce43-4ebb-9bb2-a1881520dbc3');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shunnedmessages`
--

DROP TABLE IF EXISTS `shunnedmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `shunnedmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `message` varchar(255) NOT NULL,
  `expiryDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ljbdwtxaprdadikyiulznaguewvvvigcmjug` (`userId`,`message`),
  CONSTRAINT `fk_vcfdtnxwbdwveueiwclskqdgtsepnoqlcfav` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shunnedmessages`
--

LOCK TABLES `shunnedmessages` WRITE;
/*!40000 ALTER TABLE `shunnedmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `shunnedmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sitegroups`
--

DROP TABLE IF EXISTS `sitegroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sitegroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_vqpxnoucjfdubfrmmcafykmjcwlolnaakdzb` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sitegroups`
--

LOCK TABLES `sitegroups` WRITE;
/*!40000 ALTER TABLE `sitegroups` DISABLE KEYS */;
INSERT INTO `sitegroups` VALUES (1,'Illustrashop','2024-04-30 12:49:40','2024-04-30 12:49:40',NULL,'b983c117-aebe-4dd5-92b8-5d0d49b48b82');
/*!40000 ALTER TABLE `sitegroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sites`
--

DROP TABLE IF EXISTS `sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sites` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `primary` tinyint(1) NOT NULL,
  `enabled` varchar(255) NOT NULL DEFAULT 'true',
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `language` varchar(255) NOT NULL,
  `hasUrls` tinyint(1) NOT NULL DEFAULT '0',
  `baseUrl` varchar(255) DEFAULT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_pzlgmcevlkkdeuawbtbllmhlhwpyazabkxcc` (`dateDeleted`),
  KEY `idx_vrbpqlzcvpkobxwganfpcsiiemkjgpjcwfsj` (`handle`),
  KEY `idx_vlwshhrltimpgmsbvvculvlvnzimozwyxmwt` (`sortOrder`),
  KEY `fk_kmxofyvunlqtbwgjruygwqmrmgtjumjbwdjf` (`groupId`),
  CONSTRAINT `fk_kmxofyvunlqtbwgjruygwqmrmgtjumjbwdjf` FOREIGN KEY (`groupId`) REFERENCES `sitegroups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sites`
--

LOCK TABLES `sites` WRITE;
/*!40000 ALTER TABLE `sites` DISABLE KEYS */;
INSERT INTO `sites` VALUES (1,1,1,'true','Illustrashop','default','en-US',1,'$PRIMARY_SITE_URL',1,'2024-04-30 12:49:40','2024-04-30 12:49:40',NULL,'4a826233-2673-4533-bdf4-5dd6f0487adc');
/*!40000 ALTER TABLE `sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structureelements`
--

DROP TABLE IF EXISTS `structureelements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structureelements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `structureId` int NOT NULL,
  `elementId` int DEFAULT NULL,
  `root` int unsigned DEFAULT NULL,
  `lft` int unsigned NOT NULL,
  `rgt` int unsigned NOT NULL,
  `level` smallint unsigned NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_rfsbxgyzutywnkhtuttoxywhnqbjahmwzhsc` (`structureId`,`elementId`),
  KEY `idx_uqoajsejcnpkszxzwwaczuletitespvvswif` (`root`),
  KEY `idx_bxrzyffdmsqbwwbxwixzrhwmdcnnkfsmkcmq` (`lft`),
  KEY `idx_hiafnhjfizbunaqntsaspyvdamtzdtyfuqve` (`rgt`),
  KEY `idx_brafdxyezsggqhigyntgnmfbkhcxpqcrppdm` (`level`),
  KEY `idx_fsklfjbezmtbfwfsrvxcfkdizltvuopyhhai` (`elementId`),
  CONSTRAINT `fk_alufbnebncmqsouzjaikiwtayycbujfqhixx` FOREIGN KEY (`structureId`) REFERENCES `structures` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structureelements`
--

LOCK TABLES `structureelements` WRITE;
/*!40000 ALTER TABLE `structureelements` DISABLE KEYS */;
/*!40000 ALTER TABLE `structureelements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `structures`
--

DROP TABLE IF EXISTS `structures`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `structures` (
  `id` int NOT NULL AUTO_INCREMENT,
  `maxLevels` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_heecmnotomvmjaccazrtpjjbyfdzrzpmblki` (`dateDeleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `structures`
--

LOCK TABLES `structures` WRITE;
/*!40000 ALTER TABLE `structures` DISABLE KEYS */;
/*!40000 ALTER TABLE `structures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `systemmessages`
--

DROP TABLE IF EXISTS `systemmessages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `systemmessages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `language` varchar(255) NOT NULL,
  `key` varchar(255) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_ejgdvfszcdvotfmhuadviygbmnzxvlwqiwbp` (`key`,`language`),
  KEY `idx_dnazljwnictqihiauxokuinhuponmvwjukej` (`language`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `systemmessages`
--

LOCK TABLES `systemmessages` WRITE;
/*!40000 ALTER TABLE `systemmessages` DISABLE KEYS */;
/*!40000 ALTER TABLE `systemmessages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `taggroups`
--

DROP TABLE IF EXISTS `taggroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `taggroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fieldLayoutId` int DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_jseurpqqeusayfnapaayvivhowndiswxdbwz` (`name`),
  KEY `idx_nnuoatwxwgjncmuufbqhnblqukvbubxluwmp` (`handle`),
  KEY `idx_jlhbelbfcfoewfcnhhnrhktuvnbltaolrsof` (`dateDeleted`),
  KEY `fk_hadqmevgteluzrnaztnjawdkmnwrbcsmghmg` (`fieldLayoutId`),
  CONSTRAINT `fk_hadqmevgteluzrnaztnjawdkmnwrbcsmghmg` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taggroups`
--

LOCK TABLES `taggroups` WRITE;
/*!40000 ALTER TABLE `taggroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `taggroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tags`
--

DROP TABLE IF EXISTS `tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tags` (
  `id` int NOT NULL,
  `groupId` int NOT NULL,
  `deletedWithGroup` tinyint(1) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_vkzfxkowtnjzahcpbbfwlbqaluckxnmbktda` (`groupId`),
  CONSTRAINT `fk_gbgaupvdouppeclttdwqbgxyhnpfupldtbyc` FOREIGN KEY (`groupId`) REFERENCES `taggroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_pnqhvdjpxhajsepdpzbrfalcyrkmyeanupkh` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tags`
--

LOCK TABLES `tags` WRITE;
/*!40000 ALTER TABLE `tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tokens`
--

DROP TABLE IF EXISTS `tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tokens` (
  `id` int NOT NULL AUTO_INCREMENT,
  `token` char(32) NOT NULL,
  `route` text,
  `usageLimit` tinyint unsigned DEFAULT NULL,
  `usageCount` tinyint unsigned DEFAULT NULL,
  `expiryDate` datetime NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_wacznztrfeiovlcneooummttttccikmbrriz` (`token`),
  KEY `idx_embwobuobmunbzpdazlgbolhqjblwivrhkmv` (`expiryDate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tokens`
--

LOCK TABLES `tokens` WRITE;
/*!40000 ALTER TABLE `tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `description` text,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_ymvhlsibpoobigdctwkzfkfoiymbwrwgamil` (`handle`),
  KEY `idx_cezsipyzcszjcizrmenqrkovufnemmsigpzr` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroups_users`
--

DROP TABLE IF EXISTS `usergroups_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usergroups_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `groupId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xzmtebycemzgcqujeihjublaawcczysuljqs` (`groupId`,`userId`),
  KEY `idx_dlxppwdqakvzzrsdfyjuxnwgjnpiwsgiihnj` (`userId`),
  CONSTRAINT `fk_bripziateoytitvnejbnqjcrbledoeiotkfu` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_kcwxrwvzrmgnpvwstndicbslvyjpnjjdtxff` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups_users`
--

LOCK TABLES `usergroups_users` WRITE;
/*!40000 ALTER TABLE `usergroups_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `usergroups_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions`
--

DROP TABLE IF EXISTS `userpermissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_llhjcbhnefwrflgskrjxpzxkjabxgdcwmpjc` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions`
--

LOCK TABLES `userpermissions` WRITE;
/*!40000 ALTER TABLE `userpermissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_usergroups`
--

DROP TABLE IF EXISTS `userpermissions_usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_usergroups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `groupId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_xyybllmmjdrwisqhkjmbxbuqwjhzwfujixpv` (`permissionId`,`groupId`),
  KEY `idx_qzkftwoazfxklkzzdvkrbcvkmwzfdnwyknxo` (`groupId`),
  CONSTRAINT `fk_gmcqtuwahkhmnxrhoihngdslsgmsclfdpups` FOREIGN KEY (`groupId`) REFERENCES `usergroups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_gnlwqfwcvjemzrpwwgsfzttnprmgfwlqfikh` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_usergroups`
--

LOCK TABLES `userpermissions_usergroups` WRITE;
/*!40000 ALTER TABLE `userpermissions_usergroups` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpermissions_users`
--

DROP TABLE IF EXISTS `userpermissions_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpermissions_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `permissionId` int NOT NULL,
  `userId` int NOT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_onpkibgwwjbvpddkfrtrynmxpkvaipwfdgym` (`permissionId`,`userId`),
  KEY `idx_rpkainsrshiguwdmjwufaipwxxzvwwpecmtm` (`userId`),
  CONSTRAINT `fk_cpxbevpzbixljjnjqfdmlincspamueebunaw` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_esxowlvzmwnvzrbybxncfnhlxtzoqfnbgzya` FOREIGN KEY (`permissionId`) REFERENCES `userpermissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpermissions_users`
--

LOCK TABLES `userpermissions_users` WRITE;
/*!40000 ALTER TABLE `userpermissions_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `userpermissions_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userpreferences`
--

DROP TABLE IF EXISTS `userpreferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userpreferences` (
  `userId` int NOT NULL AUTO_INCREMENT,
  `preferences` json DEFAULT NULL,
  PRIMARY KEY (`userId`),
  CONSTRAINT `fk_bctnumlyzealqrtyrzerwrofwsuyoedpvkvj` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userpreferences`
--

LOCK TABLES `userpreferences` WRITE;
/*!40000 ALTER TABLE `userpreferences` DISABLE KEYS */;
INSERT INTO `userpreferences` VALUES (1,'{\"language\": \"en-US\"}');
/*!40000 ALTER TABLE `userpreferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL,
  `photoId` int DEFAULT NULL,
  `active` tinyint(1) NOT NULL DEFAULT '0',
  `pending` tinyint(1) NOT NULL DEFAULT '0',
  `locked` tinyint(1) NOT NULL DEFAULT '0',
  `suspended` tinyint(1) NOT NULL DEFAULT '0',
  `admin` tinyint(1) NOT NULL DEFAULT '0',
  `username` varchar(255) DEFAULT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `lastLoginDate` datetime DEFAULT NULL,
  `lastLoginAttemptIp` varchar(45) DEFAULT NULL,
  `invalidLoginWindowStart` datetime DEFAULT NULL,
  `invalidLoginCount` tinyint unsigned DEFAULT NULL,
  `lastInvalidLoginDate` datetime DEFAULT NULL,
  `lockoutDate` datetime DEFAULT NULL,
  `hasDashboard` tinyint(1) NOT NULL DEFAULT '0',
  `verificationCode` varchar(255) DEFAULT NULL,
  `verificationCodeIssuedDate` datetime DEFAULT NULL,
  `unverifiedEmail` varchar(255) DEFAULT NULL,
  `passwordResetRequired` tinyint(1) NOT NULL DEFAULT '0',
  `lastPasswordChangeDate` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_aikuhkzulpsrpaiajvfntdlwyfjxwszrsfkv` (`active`),
  KEY `idx_hwuewkvqcsvwjyusrmbipdtczpkeuukivcce` (`locked`),
  KEY `idx_uklfoeehorbuoxpojeuenxebocmwrgjvksba` (`pending`),
  KEY `idx_dflbprojumwscajbbffoiukqevvecgjxmhln` (`suspended`),
  KEY `idx_ttnnlusxtrlvhoikfisskdaufbwzdgzhxfyt` (`verificationCode`),
  KEY `idx_tyqmsxkfxhxunwzuligafgdpmlebaeeejqwd` (`email`),
  KEY `idx_gzpztambzdvqwoqmuibdsiixhtshqmswysqk` (`username`),
  KEY `fk_fhyihwiwmedhluldcflrdzbswtntddswwfqj` (`photoId`),
  CONSTRAINT `fk_dnouofuetmshgqteufsplygoravuxnptczau` FOREIGN KEY (`id`) REFERENCES `elements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_fhyihwiwmedhluldcflrdzbswtntddswwfqj` FOREIGN KEY (`photoId`) REFERENCES `assets` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,1,0,0,0,1,'robbenathan',NULL,NULL,NULL,'nathan.ddk@outlook.com','$2y$13$HLIMo7gYWacqz4KjO.BxzeXxml3mMv/P5NkomMgrV.UHxQjVIHG.O','2024-05-13 12:59:41',NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,NULL,0,'2024-04-30 12:49:40','2024-04-30 12:49:40','2024-05-13 12:59:41');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumefolders`
--

DROP TABLE IF EXISTS `volumefolders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumefolders` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parentId` int DEFAULT NULL,
  `volumeId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `path` varchar(255) DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_lpadllfnufvgjrbsxygkznftmllwunevigvn` (`name`,`parentId`,`volumeId`),
  KEY `idx_bkwwmiobxieymlroeimqqdsrixqohunyridu` (`parentId`),
  KEY `idx_eewesrnrwllmcwybybrcsrjzgdtpprhljckm` (`volumeId`),
  CONSTRAINT `fk_atlnrtalrlnjgguaxdhecwrysgdtgbvbaebl` FOREIGN KEY (`volumeId`) REFERENCES `volumes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tadcfcmrwtfkbdoxxyoktpfywukimtssxbzx` FOREIGN KEY (`parentId`) REFERENCES `volumefolders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumefolders`
--

LOCK TABLES `volumefolders` WRITE;
/*!40000 ALTER TABLE `volumefolders` DISABLE KEYS */;
INSERT INTO `volumefolders` VALUES (1,NULL,1,'Images','','2024-05-02 12:48:55','2024-05-02 12:48:55','6344adbe-288a-497a-ba45-7126b422b704'),(2,NULL,NULL,'Temporary Uploads',NULL,'2024-05-02 12:49:02','2024-05-02 12:49:02','5d93344a-194f-4c1d-80f8-89a3692b859f'),(3,2,NULL,'user_1','user_1/','2024-05-02 12:49:02','2024-05-02 12:49:02','58a01229-510d-4393-9317-ec57f911d4fe');
/*!40000 ALTER TABLE `volumefolders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `volumes`
--

DROP TABLE IF EXISTS `volumes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `volumes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fieldLayoutId` int DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `handle` varchar(255) NOT NULL,
  `fs` varchar(255) NOT NULL,
  `subpath` varchar(255) DEFAULT NULL,
  `transformFs` varchar(255) DEFAULT NULL,
  `transformSubpath` varchar(255) DEFAULT NULL,
  `titleTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `titleTranslationKeyFormat` text,
  `altTranslationMethod` varchar(255) NOT NULL DEFAULT 'site',
  `altTranslationKeyFormat` text,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `dateDeleted` datetime DEFAULT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_xdhdrldccxpxfwfntktytomzluauvohkqcgh` (`name`),
  KEY `idx_evbqqqoostapmrlkwdrajnuvzoglopkinuil` (`handle`),
  KEY `idx_blfkshfetneavbabswawyyztgbwgjxweozmo` (`fieldLayoutId`),
  KEY `idx_aowetmimppjvdvphewlqmjjtodbbzcnlmydg` (`dateDeleted`),
  CONSTRAINT `fk_lrrounyihyhenxijnxksxzzxcghlidbzrrvb` FOREIGN KEY (`fieldLayoutId`) REFERENCES `fieldlayouts` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `volumes`
--

LOCK TABLES `volumes` WRITE;
/*!40000 ALTER TABLE `volumes` DISABLE KEYS */;
INSERT INTO `volumes` VALUES (1,2,'Images','images','images','','','','site',NULL,'none',NULL,1,'2024-05-02 12:48:55','2024-05-02 12:48:55',NULL,'86945d3a-9e49-4245-b5cf-e27ed83e8f76');
/*!40000 ALTER TABLE `volumes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `webauthn`
--

DROP TABLE IF EXISTS `webauthn`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `webauthn` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `credentialId` varchar(255) DEFAULT NULL,
  `credential` text,
  `credentialName` varchar(255) DEFAULT NULL,
  `dateLastUsed` datetime DEFAULT NULL,
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_yacxprnhdqaahkekmtuubfwblwkjxwzcwvie` (`userId`),
  CONSTRAINT `fk_yacxprnhdqaahkekmtuubfwblwkjxwzcwvie` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `webauthn`
--

LOCK TABLES `webauthn` WRITE;
/*!40000 ALTER TABLE `webauthn` DISABLE KEYS */;
/*!40000 ALTER TABLE `webauthn` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `widgets`
--

DROP TABLE IF EXISTS `widgets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `widgets` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `type` varchar(255) NOT NULL,
  `sortOrder` smallint unsigned DEFAULT NULL,
  `colspan` tinyint DEFAULT NULL,
  `settings` json DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '1',
  `dateCreated` datetime NOT NULL,
  `dateUpdated` datetime NOT NULL,
  `uid` char(36) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_izoswnlypmmydmojdcddemsxnldznzwiddug` (`userId`),
  CONSTRAINT `fk_okauqinmxkzjmoguofvbgrdmuwphjuppvyvs` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `widgets`
--

LOCK TABLES `widgets` WRITE;
/*!40000 ALTER TABLE `widgets` DISABLE KEYS */;
INSERT INTO `widgets` VALUES (1,1,'craft\\widgets\\RecentEntries',1,NULL,'{\"limit\": 10, \"siteId\": 1, \"section\": \"*\"}',1,'2024-04-30 12:50:06','2024-04-30 12:50:06','50455b94-0d5c-46f4-a4f1-3f2e1f5fc246'),(2,1,'craft\\widgets\\CraftSupport',2,NULL,'[]',1,'2024-04-30 12:50:06','2024-04-30 12:50:06','994671a2-645d-4a94-8690-23cd481ebb4e'),(3,1,'craft\\widgets\\Updates',3,NULL,'[]',1,'2024-04-30 12:50:06','2024-04-30 12:50:06','4c996ac9-e9e6-4b7e-ad19-92d984fc47b2'),(4,1,'craft\\widgets\\Feed',4,NULL,'{\"url\": \"https://craftcms.com/news.rss\", \"limit\": 5, \"title\": \"Craft News\"}',1,'2024-04-30 12:50:06','2024-04-30 12:50:06','d8cdcc0d-e7fd-436e-b60f-3b942ceed3fb');
/*!40000 ALTER TABLE `widgets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-13 17:38:32
